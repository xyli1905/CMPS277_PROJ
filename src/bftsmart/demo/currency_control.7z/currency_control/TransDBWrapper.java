package bftsmart.demo.currency_control;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

class TransDBWrapper {
    public HashMap<String, String>copies = new HashMap<String, String>();
    public HashSet<String>read_set = new HashSet<String>();

    public String read(String key){ // todo: where to use read
        this.read_set.add(key);
        if (this.copies.containsKey(key)) {
            return this.copies.get(key);
        } else {
            // todo
        }
    }

    public boolean wtite(String key, String val){
        this.copies.put(key, val);
        return true;
    }

    public void abort(){
        this.copies.clear();
        this.read_set.clear();
        System.out.println("Abort succeed.");
    }

    public boolean commit(){
        for (String key : this.copies.keySet())
            // todo
        return false;
    }

    public Set<String> get_read_set() {
        return this.read_set;
    }

    public Set<String> get_write_set(){
        return this.copies.keySet();
    }

}