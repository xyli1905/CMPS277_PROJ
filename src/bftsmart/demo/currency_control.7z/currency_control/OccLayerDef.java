package bftsmart.demo.currency_control;

import java.util.HashMap;

public class OccLayerDef {
    public  HashMap<Integer, TransDBWrapper> wrapper_trans_map = new HashMap<Integer, TransDBWrapper>(); // key: tnc
    public  HashMap<Integer, OccExecutor> executor_trans_map = new HashMap<Integer, OccExecutor>(); // key: id
    public  int committed_trans_num = 0;

    public void create_or_update_executor_by_op(OperationDef op){
        if (this.executor_trans_map.containsKey(op.trans_id)){ // already exists
            OccExecutor exist_executor = executor_trans_map.get(op.trans_id);
            exist_executor.read_phase(op);
        }
        TransDBWrapper empty_wrapper = new TransDBWrapper();
        OccExecutor executor = new OccExecutor(empty_wrapper, this);
        executor_trans_map.put(op.trans_id, executor);
        executor.read_phase(op);
    }


    public TransDBWrapper get_cache_by_tn(int trans_id){
        assert(wrapper_trans_map.containsKey(trans_id)); // todo: try
        return wrapper_trans_map.get(trans_id);
    }

    public boolean commit_after_reach_consensus(TransDBWrapper cache){
        assert(!wrapper_trans_map.containsKey(committed_trans_num)); // todo: try
        wrapper_trans_map.put(committed_trans_num, cache);
        return cache.commit();
    }


    public void receive_from_network(byte[] msg){
        // todo: parse msg from network
        OperationDef op = parse(msg);
        create_or_update_executor_by_op(op);
    }

    // todo
    public void maintain(){

    }
}
